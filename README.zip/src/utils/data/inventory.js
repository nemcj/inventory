export const InventoryData = [{
        "id": 5554463784,
        "name": "Bergnaum Inc",
        "amount": 1
    },
    {
        "id": 5562434787,
        "name": "Smith LLC",
        "amount": 6
    },
    {
        "id": 5570204240,
        "name": "Breitenberg, Dickinson and Carter",
        "amount": 8
    },
    {
        "id": 5513480938,
        "name": "Effertz, Rosenbaum and Beahan",
        "amount": 4
    },
    {
        "id": 5578062199,
        "name": "O'Reilly Inc",
        "amount": 9
    },
    {
        "id": 5510006403,
        "name": "Ruecker-Gibson",
        "amount": 6
    },
    {
        "id": 5639072547,
        "name": "Turcotte-Dickens",
        "amount": 5
    },
    {
        "id": 5524863671,
        "name": "Kautzer, Ferry and King",
        "amount": 10
    },
    {
        "id": 5649676125,
        "name": "Thompson, Braun and Jacobs",
        "amount": 8
    },
    {
        "id": 5616995905,
        "name": "Harber-Labadie",
        "amount": 3
    },
    {
        "id": 5574372209,
        "name": "Jakubowski Group",
        "amount": 1
    },
    {
        "id": 5681827376,
        "name": "Koelpin, Jast and Schultz",
        "amount": 9
    },
    {
        "id": 5624343845,
        "name": "Dare Inc",
        "amount": 8
    },
    {
        "id": 5661546623,
        "name": "Hackett-Nienow",
        "amount": 10
    },
    {
        "id": 5570615447,
        "name": "Quitzon, Rath and Kuphal",
        "amount": 3
    },
    {
        "id": 5657251532,
        "name": "Anderson Group",
        "amount": 8
    },
    {
        "id": 5617100787,
        "name": "Wunsch Inc",
        "amount": 7
    },
    {
        "id": 5605851624,
        "name": "Smitham, Robel and Ledner",
        "amount": 7
    },
    {
        "id": 5546733068,
        "name": "Bernhard, Crooks and Conroy",
        "amount": 1
    },
    {
        "id": 5504600268,
        "name": "Pacocha-Kreiger",
        "amount": 7
    },
    {
        "id": 5623425704,
        "name": "Huel, Pagac and Robel",
        "amount": 3
    },
    {
        "id": 5566178527,
        "name": "Bins Group",
        "amount": 9
    },
    {
        "id": 5517277124,
        "name": "Senger, Roob and Anderson",
        "amount": 9
    },
    {
        "id": 5510617009,
        "name": "Hermann-Weber",
        "amount": 10
    },
    {
        "id": 5579389249,
        "name": "MacGyver-Lemke",
        "amount": 2
    },
    {
        "id": 5584653134,
        "name": "Krajcik and Sons",
        "amount": 6
    },
    {
        "id": 5550238902,
        "name": "Hamill-Prohaska",
        "amount": 9
    },
    {
        "id": 5676627737,
        "name": "Schulist, Cassin and Leannon",
        "amount": 4
    },
    {
        "id": 5565892450,
        "name": "Altenwerth-Christiansen",
        "amount": 2
    },
    {
        "id": 5689732561,
        "name": "Pollich-Lind",
        "amount": 5
    }
]